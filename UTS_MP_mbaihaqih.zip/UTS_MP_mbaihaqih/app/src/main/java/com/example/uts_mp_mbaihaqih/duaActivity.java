package com.example.uts_mp_mbaihaqih;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class duaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dua);
    }
}