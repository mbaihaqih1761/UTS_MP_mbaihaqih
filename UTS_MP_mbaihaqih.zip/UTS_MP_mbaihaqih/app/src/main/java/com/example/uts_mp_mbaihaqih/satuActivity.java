package com.example.uts_mp_mbaihaqih;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class satuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_satu);
    }
}