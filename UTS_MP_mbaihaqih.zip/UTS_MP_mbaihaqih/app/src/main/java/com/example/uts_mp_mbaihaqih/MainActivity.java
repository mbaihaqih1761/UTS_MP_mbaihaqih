package com.example.uts_mp_mbaihaqih;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.lang.annotation.Target;

public class MainActivity extends AppCompatActivity {
    Button buttonbukasatu, buttonbukadua;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonbukasatu = (Button) findViewById(R.id.buttonbukasatu);
        buttonbukadua = (Button) findViewById(R.id.buttonbukadua);

        buttonbukasatu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Bukaactsatu = new Intent(getApplicationContext(), satuActivity.class);
                startActivity(Bukaactsatu);
            }
        });
        buttonbukadua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bukadua();
            }
        });
    }
    public void Bukadua(){
        Intent Bukaactdua = new Intent(getApplicationContext(), duaActivity.class);
        startActivity(Bukaactdua);
    }
}